/*
 Course attributes after parsing:
 - title
 - subtitle
 - category
 - image_link
 - home_link
 - actual (1)
 */
function parse(courseData) {
    
    var courseCatalogJSON = JSON.parse(courseData[0].split("\n")[1]);
    courses = [];
    for(var i = 1; i < courseData.length; i++) {
        var course = {};
        var courseCode = courseData[i];
        course.home_link = "https://www.udacity.com/api/nodes/"+courseData[i]+"?depth=2&fresh=false&required_behavior=view";
        course.web_link = "https://www.udacity.com/course/viewer#!/c-"+courseData[i];
        var node = courseCatalogJSON.references.Node;
//        for (var property in node) {
//            if(property.match(new RegExp("[a-z]+?[\\d]{3}$")) !== null) {
//                courseCode = property;
//            }
//        }
        if(courseCode !== "") {
            var courseInfo = node[courseCode];
            if(courseInfo) {
                var image_link = courseInfo.catalog_entry._image.serving_url;
                if(image_link.indexOf("//") === 0) {
                    course.image_link = "http:"+image_link;
                } else {
                    course.image_link = "http://udacity.com"+image_link;
                }
                course.title = courseInfo.title;
                course.subtitle = courseInfo.catalog_entry.subtitle;
                course.first_category = "unknown";
                course.actual = courseInfo.catalog_entry._enrollable;
                course.provider = "Udacity";
                courses.push(course);
            }

        }

        
/*        var reStr = "<li data-ng[\\s\\S]*?\"/course/"+courseData[i]+"\"[\\s\\S]*?<img src=\"([\\s\\S]*?)\"[\\s\\S]*?class=\"crs-li-title\">([\\s\\S]*?)<[\\s\\S]*?class=\"crs-li-sub\">([\\s\\S]*?)<[\\s\\S]*?class=\"crs-li-tags-category\">([\\s\\S]*?)<";
        var re = new RegExp(reStr, "gi");
        while ((searchResult = re.exec(courseCatalogPage)) !== null) {
            
            var image_link = searchResult[1].trim();
            if(image_link.indexOf("//") == 0) {
                course.image_link = "http:"+image_link;
            } else {
                course.image_link = "http://udacity.com"+image_link;
            }
            course.title = searchResult[2].trim();
            course.subtitle = searchResult[3].trim();
            course.first_category = searchResult[4].trim();
            course.actual = 1;
            course.provider = "Udacity";
            courses.push(course);
        }
 */

    }
 
    return JSON.stringify(courses);
}
parse(/*[ARRAY]*/);