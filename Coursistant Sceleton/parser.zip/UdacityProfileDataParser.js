/*
 Course attributes after parsing:
 - title
 - image_link
 - home_link
 - actual (1)
 */
function parse(content) {

    var lines = content.split(/\n/);
    var profile = JSON.parse(lines[1]);
    var data = [];
    data.push("https://www.udacity.com/api/nodes?depth=2&fresh=false&keys%5B%5D=course_catalog&projection=catalog");
    if(profile.user._enrollments) {
        for(var i = 0; i < profile.user._enrollments.length; i++) {
            if(profile.user._enrollments[i].state) {
                if(profile.user._enrollments[i].state === "enrolled") {
                    data.push(profile.user._enrollments[i].node_key);
                }
            }
        }
    }
    return JSON.stringify(data);
}
parse(/*[PAGE]*/);