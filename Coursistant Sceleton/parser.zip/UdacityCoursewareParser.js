/*
 Unit attributes after parsing:
 - title
 - courseware (array)
 
 Coursware Attributes:
 - youtube_link
 - title
 - subtitle
 */
function parse(courseware) {
    
//    var lines = content.split(/\n/);
//    var courseware = JSON.parse(lines[1]);
    var units = [];
    var node = courseware.references.Node;
    var courseCode = "";
    for (var property in node) {
        if(property.match(new RegExp("[a-z]+?[\\d]{3}$")) !== null) {
            courseCode = property;
        }
    }
    if(courseCode !== "") {
        var courseUnitRefs = node[courseCode].steps_refs;
        for(var i in courseUnitRefs) {
            var unitData = node[courseUnitRefs[i].key];
            if(unitData !== undefined) {
                var unit = {};
                unit.title = unitData.title;
                var lectures = [];
                var unitLectureRefs = unitData.steps_refs;
                for(var k in unitLectureRefs) {
                    var lectureData = node[unitLectureRefs[k].key];
                    if(lectureData !== undefined) {
                        var lecture = {};
                        lecture.title = lectureData.title;
                        if(lectureData._video && lectureData.model == "Video") {
                            lecture.subtitle = "video";
                            lecture.youtube_link = "http://yotu.be/"+lectureData._video.youtube_id;
                        } else if(lectureData.model == "Exercise") {
                            lecture.subtitle = "exercise";
                            if(lectureData.lecture_ref) {
                                lecture.web_link = "/l-"+unitData.key+"/e-"+lectureData.key+"/m-"+lectureData.lecture_ref.key;
                            } else if(lectureData.quiz_ref) {
                                lecture.web_link = "/l-"+unitData.key+"/e-"+lectureData.key+"/m-"+lectureData.quiz_ref.key;
                            }
                        } else {
                            lecture.subtitle = "exercise";
                                lecture.web_link = "/l-"+unitData.key+"/m-"+lectureData.key;
                        }
                        lectures.push(lecture);
                    }
                }
            unit.courseware = lectures;
            units.push(unit);
            }
        }
    }
    
    return JSON.stringify(units);
}
// parse(/*[PAGE]*/);
parse(/*[ARRAY]*/);