/*
 Week Attributes:
 - title
 - courseware
 
 Lecture item attributes:
 - title
 - video_link
 - slides_link
 - subtitle_link
  */
function parseWeeks(page) {
    // 1 - title
    // 2 - content
    
    var re = /<div class="course-item-list-header[\s\S]*?<\/span> &nbsp;([\s\S]*?)<\/h3>([\s\S]*?)<\/ul>/gi;
    var weeks = [];
    while ((searchResult = re.exec(page)) !== null) {
        
        var week = {};
        week.title = searchResult[1].trim();
        week.courseware = parseCourseware(searchResult[2].trim());
        
        weeks.push(week);
    }
    
    return JSON.stringify(weeks);
}

function parseCourseware(content) {
    // 1 - title
    // 2 - resourceContent
    
    var re = /<a data-lecture-id[\s\S]*?>([\s\S]*?)<\/a>([\s\S]*?)<\/li>/gi;
    var lectures = [];
    while ((searchResult = re.exec(content)) !== null) {
        
        var lecture = {};
        lecture.title = parseSpan(searchResult[1].trim());
        parseResources(lecture, searchResult[2].trim());
        
        lectures.push(lecture);
    }
    
    return lectures;
}

function parseResources(lecture, resourceContent) {
    var re = /<a[\s\S]*?href="([\s\S]*?)"[\s\S]*?title="([\s\S]*?)"/gi;
    while ((searchResult = re.exec(resourceContent)) !== null) {
        var resourceLink = searchResult[1].trim();
        var resourceTitle = searchResult[2].trim();
        if(!lecture.resources) {
            lecture.resources = new Array();
        }
        if(resourceLink.indexOf("format=srt") > 0) {
            lecture.subtitles_link = resourceLink;
        } else if(resourceLink.indexOf(".mp4") > 0) {
            lecture.video_link = resourceLink;
        } else {
            var resource = {};
            resource.link = resourceLink;
            resource.title = resourceTitle;
            if(resourceLink.indexOf(".pdf") > 0) {
                resource.type = "pdf";
            } else if(resourceLink.indexOf(".ppt") > 0) {
                resource.type = "ppt";
            } else if(resourceLink.indexOf(".html") > 0) {
                resource.type = "html";
            } else if(resourceLink.indexOf(".txt") > 0) {
                resource.type = "txt";
            } else if(resourceLink.indexOf("format=txt") > 0) {
                resource.type = "txt";
            } else {
                resource.type = "unkn";
            }
            lecture.resources.push(resource);
        }
        
    }
}

function parseSpan(title) {
    var re = /([\s\S]*?)<span[\s\S]*?>[\S]*?\s([\s\S]*?)<\/span>/gi;
    var result = [title];
    var searchResult = re.exec(title);
    if((searchResult !== null) && (searchResult.length > 0)) {
        result = [searchResult[1].trim(), " [", searchResult[2].trim(), "]"];
    }
    return result.join("");
}

parseWeeks(/*[PAGE]*/);