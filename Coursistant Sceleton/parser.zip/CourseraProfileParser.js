/*
 Course attributes after parsing:
 - title
 - image_link
 - home_link
 - open_link - special for Coursera to access courseware
 - actual (1)
 - provider
 - start_date
 - first_category
 - university
 - university_short
 */
function parse(content) {
    
    var courses = [];
    for(var i in content) {
        var courseInstance = content[i];
        if(courseInstance.courses.length > 1) {
            for(var k in courseInstance.courses) {
                var course = {};
                var courseInfoItem = courseInstance.courses[k];
                course.title = courseInstance.name;
                course.image_link = courseInstance.large_icon;
                course.open_link = courseInfoItem.home_link;
                course.home_link = course.open_link + "lecture/index";
                course.web_link = course.home_link;
                course.actual = courseInfoItem.active;
                course.provider = "Coursera";
                course.start_date = startDate(courseInfoItem.start_year, courseInfoItem.start_month, courseInfoItem.start_day);
                course.end_date = endDate(course.start_date, courseInfoItem.duration_string);

                if(courseInstance.categories.length > 0) {
                    course.first_category = courseInstance.categories[0].short_name;
                } else {
                    course.first_category = "Unknown";
                }
                if(courseInstance.universities.length > 0) {
                    course.university = courseInstance.universities[0].name;
                    course.university_short = courseInstance.universities[0].abbr_name;
                } else {
                    course.university = "Unknown";
                    course.university_short = "Unknown";
                    
                }
                courses.push(course);
            }
        } else if(courseInstance.courses.length == 1) {
            var course = {};
            var courseInfoItem = courseInstance.courses[0];
            course.title = courseInstance.name;
            course.image_link = courseInstance.large_icon;
            course.open_link = courseInfoItem.home_link;
            course.home_link = course.open_link + "lecture/index";
            course.web_link = course.home_link;
            course.actual = courseInfoItem.active;
            course.provider = "Coursera";
            course.start_date = startDate(courseInfoItem.start_year, courseInfoItem.start_month, courseInfoItem.start_day);
            course.end_date = endDate(course.start_date, courseInfoItem.duration_string);

            if(courseInstance.categories.length > 0) {
                course.first_category = courseInstance.categories[0].short_name;
            } else {
                course.first_category = "Unknown";
            }
            if(courseInstance.universities.length > 0) {
                course.university = courseInstance.universities[0].name;
                course.university_short = courseInstance.universities[0].abbr_name;
            } else {
                course.university = "Unknown";
                course.university_short = "Unknown";
                
            }
            courses.push(course);
        }
    }
    
    return JSON.stringify(courses);
}

function startDate(year, month, day) {
    if(day === null && month === null) return null;
    var dayUpdated = day;
    if(dayUpdated === null) {
        dayUpdated = 1;
    }
    return new Date(year, month-1, dayUpdated+1);
}

function endDate(start_date, duration_weeks) {
    if(start_date) {
        var duration_days = duration_weeks.split(' ', 1)[0] * 7;
        var end_date = new Date();
        end_date.setTime(start_date.getTime() + duration_days * 24 * 60 * 60 * 1000);
        return end_date;
    } else {
        return null;
    }
}

parse(/*[ARRAY]*/);