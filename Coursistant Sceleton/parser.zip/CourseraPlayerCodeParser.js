/*
 Lecture Data:
 - video_link
 - quiz_link
 - subtitles
   - language
   - link
 */
function parse(page) {
    
    var re = /type="video\/mp4" src="([\s\S]*?)"[\s\S]*?kind="subtitles"([\s\S]*?)<\/video[\s\S]*?quiz_id=([\s\S]*?)&[\s\S]*?quiz_url=([\s\S]*?)&/gi;
    var lectureData = [];
    while ((searchResult = re.exec(page)) !== null) {
        
        var lecture = {};
        lecture.video_link = searchResult[1].trim();
        lecture.subtitles = parseSubtitles(searchResult[2].trim());
        lecture.quiz_link = decodeURIComponent(searchResult[4].trim()) + "?method=get_question_list&quiz_id="+searchResult[3].trim();
        
        lectureData.push(lecture);
    }
    
    return JSON.stringify(lectureData);
}

function parseSubtitles(content) {
    
    var re = /srclang="([\s\S]*?)"[\s\S]*?src="([\s\S]*?)"/gi;
    var subtitles = [];
    while ((subtitleResult = re.exec(content)) !== null) {
        
        var subtitle = {};
        subtitle.language = subtitleResult[1].trim();
        subtitle.link = subtitleResult[2].trim();
        
        subtitles.push(subtitle);
    }
    
    return subtitles;
}


parse(/*[PAGE]*/);